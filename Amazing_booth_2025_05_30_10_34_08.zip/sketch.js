let triang = true;
let quadros = true;
let linhas = true;
let numeros = true;

let checkRect;
let checkTriang;
let checkQuadros;
let checkLinhas;
let checkNumeros;
let checkLetras;
let checkTeorema;
let checkF1;
let checkF2;

function createCheckBox(p, l) {
  check = createCheckbox("", false);
  check.parent(p);
  check.style("color", "white");
  return check;
}

function setup() {
  createCanvas(windowWidth, windowHeight - 50);
  textSize(30);
  let divPai = createDiv();
  divPai.style("border-style", "solid");
  divPai.style("border-color", "white");
  divPai.style("display", "flex");

  checkRect = createCheckBox(divPai, "R");
  checkTriang = createCheckBox(divPai, "T");
  checkLetras = createCheckBox(divPai, "L");
  checkQuadros = createCheckBox(divPai, "Q");
  checkLinhas = createCheckBox(divPai, "L");
  checkNumeros = createCheckBox(divPai, "N");
  checkTeorema = createCheckBox(divPai, "T");
  checkF1 = createCheckBox(divPai, "F");
  checkF2 = createCheckBox(divPai, "F");
}

function draw() {
  background(0);
  noFill();
  if (!checkTeorema.checked()) desenharPlano();
  linha();
  coord();
  if (checkTeorema.checked()) teorema();
  if (checkF1.checked()) formula_1();
  if (checkF2.checked()) formula_2();
  if (checkRect.checked()) retangulo();
  if (checkTriang.checked()) triangulo();
  if (checkLetras.checked()) letras();

  if (checkQuadros.checked()) {
    linhas = checkLinhas.checked();
    numeros = checkNumeros.checked();

    quadroAzul();
    quadroVermelho();
    quadroAmarelo();
  }
}

function teorema() {
  strokeWeight(1);
  stroke("white");
  fill("white");
  textSize(30);
  text(
    "O quadrado da hipotenusa é igual a soma dos quadrados dos catetos",
    0,
    30
  );
}

function formula_1() {
  strokeWeight(1);
  stroke("white");
  fill("white");
  textSize(10);
  text("      2                 2                 2", 0, 55);
  textSize(30);
  text("h  = c  + c ", 0, 75);
}
function formula_2() {
  strokeWeight(1);
  stroke("white");
  fill("white");
  textSize(10);
  text("                                2                 2", 0, 105);
  textSize(30);
  text("h  = √ c  + c ", 0, 125);
  stroke(255);
  line(75, 97, 170, 97);
}

function linha() {
  strokeWeight(2);
  stroke("white");
  fill("white");
  line(250, 250, 450, 400);
  strokeWeight(1);
}

function coord() {
  stroke("white");
  fill("white");
  text("(x: 5, y: 5)", 100, 240);
  text("(x: 9, y: 8)", 460, 430);

  strokeWeight(8);
  stroke("red");
  fill("red");
  point(250, 250);
  point(450, 400);
  strokeWeight(1);
}

function letras() {
  stroke("blue");
  fill("blue");
  text("c", 255, 340);

  stroke("red");
  fill("red");
  text("c", 330, 395);

  stroke("yellow");
  fill("yellow");
  text("h", 320, 340);
}

function triangulo() {
  stroke("white");
  noFill();
  strokeWeight(2);
  triangle(250, 250, 250, 400, 450, 400);
  strokeWeight(1);
}

function retangulo() {
  stroke("white");
  noFill();
  strokeWeight(2);
  rect(250, 250, 200, 150);
}

function quadroAzul() {
  strokeWeight(1);
  stroke("blue");
  noFill();
  rect(100, 250, 150);
  if (linhas) {
    for (let i = 150; i < 300; i += 50) {
      line(i, 250, i, 400);
      line(100, i + 150, 250, i + 150);
    }
  }

  if (numeros) {
    textSize(30);
    let c = 1;
    stroke("white");
    fill("white");
    for (let y = 0; y < 3; y++) {
      for (let x = 0; x < 3; x++) {
        text(c, x * 50 + 110, y * 50 + 285);
        c++;
      }
    }
  }
}
function quadroVermelho() {
  noFill();
  stroke("red");
  rect(250, 400, 200);
  if (linhas) {
    for (let i = 250; i < 450; i += 50) {
      line(i, 400, i, 600);
      line(250, i + 150, 450, i + 150);
    }
  }

  if (numeros) {
    c = 1;
    stroke("white");
    fill("white");
    for (let y = 0; y < 4; y++) {
      for (let x = 0; x < 4; x++) {
        text(c, x * 50 + 260, y * 50 + 435);
        c++;
      }
    }
  }
}
function quadroAmarelo() {
  push();
  noFill();
  stroke("yellow");
  translate(250, 250);
  rotate(0.64);
  rect(0, -250, 250);

  if (linhas) {
    for (let i = 50; i < 250; i += 50) {
      noFill();
      line(i, -250, i, 0);
      line(0, i - 250, 250, i - 250);
    }
  }

  if (numeros) {
    c = 1;
    stroke("white");
    fill("white");
    for (let y = 0; y < 5; y++) {
      for (let x = 0; x < 5; x++) {
        text(c, x * 50 + 10, y * 50 - 215);
        c++;
      }
    }
  }
  pop();
}

function desenharPlano() {
  push();
  // translate(10, 10);
  stroke(255, 255, 0);
  strokeWeight(2);
  line(0, -height, 0, height);

  stroke(0, 255, 0);
  line(-width, 0, width, 0);
  let cx = 1;
  textAlign(CENTER, CENTER);
  textSize(30);

  for (var x = 50; x <= width; x += 50) {
    strokeWeight(1);
    stroke(50);
    line(x, -height, x, height);
    line(-x, -height, -x, height);

    stroke(255);
    fill(255);
    text(cx, x - 25, 25);
    text(-cx, -x + 25, -25);
    cx++;
  }

  let cy = 1;
  for (var y = 50; y <= height; y += 50) {
    strokeWeight(1);
    stroke(50);
    line(-width, y, width, y);
    line(-width, -y, width, -y);

    stroke(255);
    fill(255);
    text(cy, 25, y - 25);
    text(-cy, -25, -y + 25);
    cy++;
  }

  stroke(255, 0, 0);
  strokeWeight(10);
  point(0, 0);
  pop();
}
